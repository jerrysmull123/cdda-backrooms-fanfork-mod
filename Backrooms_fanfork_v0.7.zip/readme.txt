PLEASE TURN CITY SIZE TO ZERO!!!
PLEASE TURN CITY SIZE TO ZERO!!!
PLEASE TURN CITY SIZE TO ZERO!!!
thank you


A Backrooms-themed mod for Cataclysm: Dark Days Ahead.

This is a continuation of TGWeavers backrooms mod. 

current features:

-basic almond water. 
-hounds
-skin stealers
-fixed Faceling item drops
planned features:

- level 1, 2, 3, etc
- More backroom specific entities such as smilers, etc
- firesalt and other backroom specific items
- jerry :)
- M.E.G and other faction bases on lower levals
- more types of almond water
- the hub and leval keys

## Warning: the Backrooms are the only location in the entire world, characters trying to start in other locations will fail to spawn.
Turning city size to 0 is recommended just to avoid strangeness in map labeling.

please check out TGWeavers stuff, he's a cool guy.
mod dedicated to my best friend Ethan H
-jerry mull